/*
 * Created by JFormDesigner on Sat Feb 26 18:17:09 CST 2022
 */

package gui.test;

import java.awt.*;
import javax.swing.*;

/**
 * @author unknown
 */
public class ManagementDialog extends JDialog {
    public ManagementDialog(Window owner) {
        super(owner);
        initComponents();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - unknown
        panel3 = new JPanel();
        bCancel = new JButton();
        bDelete = new JButton();
        bLog = new JButton();
        bSave = new JButton();
        panel4 = new JPanel();
        panel1 = new JPanel();
        lBookName = new JLabel();
        lOwner = new JLabel();
        lType = new JLabel();
        panel2 = new JPanel();
        tfBookName = new JTextField();
        tfOwner = new JTextField();
        tfType = new JTextField();

        //======== this ========
        var contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== panel3 ========
        {
            panel3.setBorder ( new javax . swing. border .CompoundBorder ( new javax . swing. border .TitledBorder ( new javax . swing
            . border .EmptyBorder ( 0, 0 ,0 , 0) ,  "JFor\u006dDesi\u0067ner \u0045valu\u0061tion" , javax. swing .border . TitledBorder
            . CENTER ,javax . swing. border .TitledBorder . BOTTOM, new java. awt .Font ( "Dia\u006cog", java .
            awt . Font. BOLD ,12 ) ,java . awt. Color .red ) ,panel3. getBorder () ) )
            ; panel3. addPropertyChangeListener( new java. beans .PropertyChangeListener ( ){ @Override public void propertyChange (java . beans. PropertyChangeEvent e
            ) { if( "bord\u0065r" .equals ( e. getPropertyName () ) )throw new RuntimeException( ) ;} } )
            ;
            panel3.setLayout(new GridLayout());

            //---- bCancel ----
            bCancel.setText("\u53d6\u6d88");
            panel3.add(bCancel);

            //---- bDelete ----
            bDelete.setText("\u5220\u9664");
            panel3.add(bDelete);

            //---- bLog ----
            bLog.setText("\u65e5\u5fd7");
            panel3.add(bLog);

            //---- bSave ----
            bSave.setText("\u4fdd\u5b58");
            panel3.add(bSave);
        }
        contentPane.add(panel3, BorderLayout.SOUTH);

        //======== panel4 ========
        {
            panel4.setLayout(new GridLayout(1, 2));

            //======== panel1 ========
            {
                panel1.setLayout(new GridLayout(3, 1));

                //---- lBookName ----
                lBookName.setText("\u4e66\u540d");
                panel1.add(lBookName);

                //---- lOwner ----
                lOwner.setText("\u6240\u6709\u8005");
                panel1.add(lOwner);

                //---- lType ----
                lType.setText("\u7c7b\u578b");
                panel1.add(lType);
            }
            panel4.add(panel1);

            //======== panel2 ========
            {
                panel2.setLayout(new GridLayout(3, 1));
                panel2.add(tfBookName);
                panel2.add(tfOwner);
                panel2.add(tfType);
            }
            panel4.add(panel2);
        }
        contentPane.add(panel4, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - unknown
    private JPanel panel3;
    private JButton bCancel;
    private JButton bDelete;
    private JButton bLog;
    private JButton bSave;
    private JPanel panel4;
    private JPanel panel1;
    private JLabel lBookName;
    private JLabel lOwner;
    private JLabel lType;
    private JPanel panel2;
    private JTextField tfBookName;
    private JTextField tfOwner;
    private JTextField tfType;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
