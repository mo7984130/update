package gui.test;

import entity.Book;
import unit.DAOUnit;

public class test {

    public static void main(String[] args) {
        System.out.println(new DAOUnit<>(new Book()).get("isAvailable"  , String.valueOf(1)).size());
        System.out.println(new DAOUnit<>(new Book()).getTotal());
        System.out.println((new DAOUnit<>(new Book()).getTotal() - new DAOUnit<>(new Book()).get("isAvailable"  , String.valueOf(1)).size()));
    }

}
