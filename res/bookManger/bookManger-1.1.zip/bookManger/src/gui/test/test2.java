package gui.test;

import entity.Book;
import unit.DAOUnit;

import java.util.ArrayList;

public class test2 {

    public static void main(String[] args) {
        ArrayList<Book> books = new DAOUnit<>(new Book()).list();
        for (Book book : books){
            System.out.println(book.getBookName() + "   " + book.getOwner() + " __");
        }
    }

}
