package update;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import gui.frame.MainFrame;
import log.Log;
import unit.JSONUnit;
import unit.WebUnit;
import unit.ZipUnit;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.zip.*;

/**
 * @author mo7984130
 * @Classname Update
 * @Description 更新程序
 * @Date 2022/2/27 9:55 上午
 */

public class Update {

    public Update(String appName){
        JSONObject localJson = JSONUnit.readJSON(new File(Update.class.getResource("/update").getPath() + File.separator + "version.json"));
        if (checkVersion("bookManger" , Float.parseFloat(localJson.getString("version")))) {
            int option = JOptionPane.showConfirmDialog(null,"检测到新版本，是否更新?");
            if (option == JOptionPane.YES_OPTION){
                update(appName);

                localJson.put("version" , getNewJSONObject("bookManger").get("version"));
                JSONUnit.saveJSON(localJson , new File(Update.class.getResource("/update").getPath() + File.separator + "version.json"));

                JOptionPane.showMessageDialog(null , "更新成功！请重新打开软件!");

                System.exit(0);
            }
        }
    }

    public boolean update(String appName){
        JSONObject app = getNewJSONObject(appName);
        String path = app.getString("path");
        File file = new File(Update.class.getResource("/update").getPath() + File.separator + "zip");
        if (!file.exists()){
            file.mkdirs();
        }
        file = new File(file ,  path.split("/")[1]);
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        WebUnit.downloadFileByUrl("http://localhost:8080/web/res/" + path , file);

        String appPath = System.getProperty("user.dir");
        appPath = new File(appPath).getParent();

        try {
            ZipUnit.decompressZipFileToDestination(new ZipFile(file) , appPath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        file.delete();

        return false;
    }

    public static boolean checkVersion(String appName , float localVersion){
        JSONObject app = getNewJSONObject(appName);
        Float newVersion = app.getFloat("version");
        if (newVersion > localVersion){
            return true;
        }else{
            return false;
        }
    }

    public static JSONObject getNewJSONObject(String appName) {
        ArrayList<String> lines = WebUnit.getListByUrl("http://localhost:8080/web/res/getVersion.json");
        StringBuilder jsonString = new StringBuilder();
        for (String line : lines){
            jsonString.append(line);
        }
        return JSON.parseObject(jsonString.toString()).getJSONObject(appName);
    }

}
