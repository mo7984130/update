package startup;

import update.Update;

import static gui.frame.MainFrame.getMainFrame;

/**
 * @author mo7984130
 * @Classname Bootstrap
 * @Description TODO
 * @Date 2022/2/12 10:49 下午
 */
public class Bootstrap {

    public static void main(String[] args) {

        new Update("bookManger");

        getMainFrame().setVisible(true);

    }

}
