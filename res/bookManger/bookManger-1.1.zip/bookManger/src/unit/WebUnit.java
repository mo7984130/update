package unit;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * @author mo7984130
 * @Classname WebUnit
 * @Description TODO
 * @Date 2022/2/27 12:05 下午
 */
public class WebUnit {

    public static ArrayList<String> getListByUrl(String url) {

        ArrayList<String> list = new ArrayList<>();

        InputStreamReader isr = null;

        try {
            //判断为http还是https ， 并连接
            if (url.startsWith("https")){
                HttpsURLConnection connection = (HttpsURLConnection) new URL(url).openConnection();
                isr = new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8);
            }
            else if (url.startsWith("http")){
                HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                isr = new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8);
            }

            //读取
            try (
                    BufferedReader br = new BufferedReader(isr)
            ){

                while (true){
                    String line = br.readLine();

                    if (line != null){

                        list.add(line);
                    }else {
                        break;
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void downloadFileByUrl(String url , File file){

        InputStream is = null;

        try {
            //判断为http还是https ， 并连接
            if (url.startsWith("https")){
                HttpsURLConnection connection = (HttpsURLConnection) new URL(url).openConnection();
                is = connection.getInputStream();
            }
            else if (url.startsWith("http")){
                HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                is = connection.getInputStream();
            }

            //读取
            try (
                    FileOutputStream fos = new FileOutputStream(file)
            ){

                int byteRead = 0;
                byte[] buffer = new byte[1024];

                while((byteRead = is.read(buffer) )!= -1){
                    fos.write(buffer , 0 ,byteRead);
                }

            }catch (Exception e){
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
