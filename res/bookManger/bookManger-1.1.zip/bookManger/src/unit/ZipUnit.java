package unit;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * @author mo7984130
 * @Classname ZipUnit
 * @Description TODO
 * @Date 2022/2/27 2:59 下午
 */
public class ZipUnit {

    public static void decompressZipFileToDestination(ZipFile zipFile , String destination){
        try {
            Enumeration<?> entries = zipFile.entries();

            while(entries.hasMoreElements()) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                if (entry.isDirectory()){
                    new File(destination + File.separator + entry.getName()).mkdirs();
                }else{
                    File oneFile = new File(destination + File.separator + entry.getName());

                    if (entry.getName().startsWith("__MACOSX")){
                        continue;
                    }

                    if (oneFile.exists()){
                        oneFile.delete();
                    }

                    oneFile.createNewFile();

                    InputStream is = zipFile.getInputStream(entry);

                    FileOutputStream fos = new FileOutputStream(oneFile);

                    int len;

                    byte[] buf = new byte[1024];

                    while ((len = is.read(buf)) != -1) {

                        fos.write(buf, 0, len);

                    }

                    fos.close();

                    is.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
