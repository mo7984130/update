package unit;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.io.*;

/**
 * @author mo7984130
 * @Classname JSONUnit
 * @Description TODO
 * @Date 2022/2/27 2:58 下午
 */
public class JSONUnit {

    public static void saveJSON(JSONObject json , File file){

        file.delete();
        if (!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try(
                FileWriter fw = new FileWriter(file);
                PrintWriter pw = new PrintWriter(fw)

        ){

            pw.print(json);
            pw.flush();

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public static JSONObject readJSON(File file){

        JSONObject json = null;

        try(
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);

        ){

            StringBuilder sb = new StringBuilder();
            while(true){
                String line = br.readLine();
                if(line == null){
                    break;
                }
                sb.append(line);
            }
            json = JSON.parseObject(sb.toString());

        }catch (Exception e){
            e.printStackTrace();
        }

        return json;

    }

}
