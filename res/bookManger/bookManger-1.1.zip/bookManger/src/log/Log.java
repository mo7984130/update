package log;

import entity.Book;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author mo7984130
 */
public class Log {

    Book book;

    public File logFile;

    File allLogFile;

    public Log(Book book) {
        this.book = book;

        logFile = new File(getLogFilePath() + book.getBookName() + "_" + book.getOwner() + ".txt");

        if (!logFile.exists()) {
            try {
                logFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        initAllLogFile();
    }

    public static ArrayList<String> read(File file){

        ArrayList<String> log = new ArrayList<>();

        try (
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file) , StandardCharsets.UTF_8))
        ){

            while(true){
                String line = br.readLine();
                if (null == line){
                    break;
                }

                log.add(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return log;

    }

    public void println(String type) {
        String message = "《%s》 被 %s %s 于 %s (备注:%s)";
        if ("add".equals(type)) {
            message = String.format(message, book.getBookName(), book.getOwner() , "添加" , book.getAddTime(),  book.getRemark());
        } else if ("lend".equals(type)) {
            message = String.format(message, book.getBookName(), book.getBorrower() , "借走" , book.getLendTime(), book.getRemark());
        } else if ("return".equals(type)) {
            message = String.format(message, book.getBookName(), book.getBorrower() , "归还" , book.getReturnTime(), book.getRemark());
        }
        ArrayList<String> lines = read(logFile);
        PrintWriter pw = getPrintWriter(logFile);
        for (String line : lines){
            pw.println(line);
        }
        pw.println(message);
        pw.flush();
        pw.close();

        printlnToAllLogFile(message);
    }

    private void printlnToAllLogFile(String[] messages){
        ArrayList<String> lines = read(allLogFile);
        PrintWriter pw = getPrintWriter(allLogFile);
        for(String line : lines){
            pw.println(line);
        }

        for (String message : messages){
            pw.println(message);
        }

        pw.flush();

        pw.close();
    }

    private void printlnToAllLogFile(String message){
        printlnToAllLogFile(new String[]{message});
    }

    private void initAllLogFile(){
        String date = new SimpleDateFormat("yyyy-MM").format(new Date());
        allLogFile = new File(getLogFilePath() + date);

        if (!allLogFile.exists()){
            allLogFile.mkdirs();
        }

        allLogFile = new File(allLogFile , new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + ".txt");

        if (!allLogFile.exists()){
            try {
                allLogFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String getLogFilePath() {
        return Log.class.getResource("/log").getPath() + File.separator;
    }

    private PrintWriter getPrintWriter(File file) {

        PrintWriter pw = null;

        try {
            FileWriter ous = new FileWriter(file);
            pw = new PrintWriter(ous);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pw;

    }

    public static File getAllLogFile(){
        String date = new SimpleDateFormat("yyyy-MM").format(new Date());
        File allLogFile = new File(getLogFilePath() + date);

        if (!allLogFile.exists()){
            allLogFile.mkdirs();
        }

        allLogFile = new File(allLogFile , new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + ".txt");

        if (!allLogFile.exists()){
            try {
                allLogFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return allLogFile;
    }

    public void renameTo(String fileName){

        logFile.renameTo(new File(getLogFilePath() + fileName));

    }

    public static void printlnUpdateMessage(Book oldBook, Book newBook){

        String message = "《%s》的信息被修改 以下为 对比";
        String infor = "%s: 书名: %s ; 所有者: %s ; 种类: %s";

        String message1 = String.format(message , oldBook.getBookName());
        String message2 = String.format(infor , "旧" , oldBook.getBookName() , oldBook.getOwner() , oldBook.getType());
        String message3 = String.format(infor , "新" , newBook.getBookName() , newBook.getOwner() , newBook.getType());

        Log newLog = new Log(newBook);
        ArrayList<String> lines = read(newLog.logFile);
        PrintWriter pw = newLog.getPrintWriter(newLog.logFile);
        for (String line : lines){
            pw.println(line);
        }

        pw.println(message1);
        pw.println(message2);
        pw.println(message3);
        pw.flush();
        pw.close();

        newLog.printlnToAllLogFile(new String[]{message1 , message2 , message3});

    }

}
