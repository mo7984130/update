package dialog;

import entity.Book;
import gui.panel.BookPanel;
import log.Log;
import unit.DAOUnit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;

/**
 * @author mo7984130
 * @Classname ManagementDialog
 * @Description TODO
 * @Date 2022/2/26 6:24 下午
 */
public class ManagementDialog extends JDialog {

    private JPanel panel3;
    private JButton bCancel;
    private JButton bDelete;
    private JButton bLog;
    private JButton bSave;
    private JPanel panel4;
    private JPanel panel1;
    private JLabel lBookName;
    private JLabel lOwner;
    private JLabel lType;
    private JPanel panel2;
    private JTextField tfBookName;
    private JTextField tfOwner;
    private JTextField tfType;

    private Book book;

    public ManagementDialog(JFrame f , Book book){
        super(f , true);

        setTitle("管理");
        setSize(300, 200);
        setLocationRelativeTo(null);

        this.book = book;

        panel3 = new JPanel();
        bCancel = new JButton();
        bDelete = new JButton();
        bLog = new JButton();
        bSave = new JButton();
        panel4 = new JPanel();
        panel1 = new JPanel();
        lBookName = new JLabel();
        lOwner = new JLabel();
        lType = new JLabel();
        panel2 = new JPanel();
        tfBookName = new JTextField();
        tfOwner = new JTextField();
        tfType = new JTextField();

        setLayout(new BorderLayout());

        panel3.setLayout(new GridLayout());

        bCancel.setText("\u53d6\u6d88");
        bCancel.addActionListener(this::cancel);
        panel3.add(bCancel);

        bDelete.setText("\u5220\u9664");
        bDelete.addActionListener(this::delete);
        panel3.add(bDelete);

        bLog.setText("\u65e5\u5fd7");
        bLog.addActionListener(this::showLog);
        panel3.add(bLog);

        bSave.setText("\u4fdd\u5b58");
        bSave.addActionListener(this::save);
        panel3.add(bSave);

        add(panel3, BorderLayout.SOUTH);

        panel4.setLayout(new GridLayout(1, 2));


        panel1.setLayout(new GridLayout(3, 1));

        //---- lBookName ----
        lBookName.setText("\u4e66\u540d");
        panel1.add(lBookName);

        //---- lOwner ----
        lOwner.setText("\u6240\u6709\u8005");
        panel1.add(lOwner);

        //---- lType ----
        lType.setText("\u7c7b\u578b");
        panel1.add(lType);

        panel4.add(panel1);

        panel2.setLayout(new GridLayout(3, 1));
        panel2.add(tfBookName);
        panel2.add(tfOwner);
        panel2.add(tfType);
        init();

        panel4.add(panel2);

        add(panel4, BorderLayout.CENTER);
    }

    private void init(){

        tfBookName.setText(book.getBookName());
        tfOwner.setText(book.getOwner());
        tfType.setText(book.getType());

    }

    private void cancel(ActionEvent e){
        dispose();
    }

    private void delete(ActionEvent e){
        int option = JOptionPane.showConfirmDialog(this , "确认删除？");
        if (option == JOptionPane.YES_OPTION){
            new DAOUnit<>(book).delete(book);

            new Log(book).logFile.delete();

            JOptionPane.showMessageDialog(this , "删除成功");
            dispose();

            BookPanel.getBookPanel().refresh();
        }
    }

    private void showLog(ActionEvent e){
        LogDialog logDialog = new LogDialog(new Log(book).logFile);
        logDialog.setVisible(true);
    }

    private void save(ActionEvent e){
        int option = JOptionPane.showConfirmDialog(this , "确认保存？");
        if (option == JOptionPane.YES_OPTION){

            new Log(book).renameTo(tfBookName.getText() + "_" + tfOwner.getText() + ".txt");
            Book oldBook = new DAOUnit<>(book).get("id" , String.valueOf(book.getId())).get(0);

            book.setBookName(tfBookName.getText());
            book.setOwner(tfOwner.getText());
            book.setType(tfType.getText());

            new DAOUnit<>(book).update(book);

            Log.printlnUpdateMessage(oldBook , book);

            JOptionPane.showMessageDialog(this , "保存成功!");

            BookPanel.getBookPanel().refresh();

            dispose();
        }

    }

}
